# Spec Doc Tools (`asntools-spec-toc`, `asntools-spec-extract`)

These tools work with spec HTML documents in `docs/` and their TOC JSON files (same basename, suffixed with `_toc.json`).

## Setup

Install the project so the entrypoints are available:

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -e .
```

## Files Expected

For a document basename like `38300-j00`:

- HTML: `docs/38300-j00.html`
- TOC JSON: `docs/38300-j00_toc.json`

You can pass either the basename or a path to the HTML/TOC file as `DOC`.

## Inspect TOC

Print the table of contents:

```bash
asntools-spec-toc 38300-j00
```

Filter by prefix (clause or id prefix):

```bash
asntools-spec-toc 38300-j00 --prefix 4.7
asntools-spec-toc 38300-j00 --prefix 4-7
```

Search by substring:

```bash
asntools-spec-toc 38300-j00 --search architecture
```

Emit JSON instead of text:

```bash
asntools-spec-toc 38300-j00 --format json
```

Use a non-default docs directory:

```bash
asntools-spec-toc 38300-j00 --docs-dir /path/to/docs
```

## Extract a Section

By default this extracts the section, converts HTML→Markdown, saves it to an auto-named file, and prints the output path:

```bash
asntools-spec-extract 38300-j00 4-7-2
```

Section selectors accepted:

- Clause id: `4.7.2`
- Exact heading id: `4-7-2-protocol-stacks`
- Heading id prefix: `4-7-2` (resolves to the best matching heading id)

### Output Control

Write to an explicit file path:

```bash
asntools-spec-extract 38300-j00 4-7-2 --output artifacts/my_section.md
```

Choose the directory for auto-named markdown output:

```bash
asntools-spec-extract 38300-j00 4-7-2 --out-dir artifacts/sections
```

Return HTML or plain text instead of Markdown:

```bash
asntools-spec-extract 38300-j00 4-7-2 --format html
asntools-spec-extract 38300-j00 4-7-2 --format text
```

Exclude the heading tag itself (extract only the content following it):

```bash
asntools-spec-extract 38300-j00 4-7-2 --no-include-heading
```

